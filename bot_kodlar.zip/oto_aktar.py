import asyncio
from pyrogram import Client

# API BİLGİLERİ (my.telegram.org adresinden alınan)
API_ID = 26963668  # Buraya kendi API ID'ni yaz kanka
API_HASH = "89c3b1b5c65ba624f175f5385b3c14b7"  # Buraya kendi API HASH'ini yaz kanka

SOURCE_CHAT = "elitesovcular"
TARGET_CHAT = "EliteModeller"
INTERVAL_MINUTES = 5

app = Client("Fatmanur", api_id=API_ID, api_hash=API_HASH)

async def main():
    async with app:
        print("Bot başlatıldı, mesajlar taranıyor...")
        
        # Kaynak gruptaki mesajları en eskiden yeniye doğru alıyoruz
        messages = []
        async for msg in app.get_chat_history(SOURCE_CHAT, reverse=True):
            # Sadece servis mesajı olmayan gerçek mesajları topluyoruz
            if not msg.service:
                messages.append(msg)
                
        print(f"Toplam {len(messages)} adet iletilecek mesaj bulundu.")
        
        for index, msg in enumerate(messages, 1):
            try:
                print(f"[{index}/{len(messages)}] Mesaj aktarılıyor...")
                
                # Medya/Yazı/Premium emoji formatını tamamen koruyarak kopyalıyoruz
                await msg.copy(chat_id=TARGET_CHAT)
                
                print(f"Başarıyla aktarıldı. {INTERVAL_MINUTES} dakika bekleniyor...")
                await asyncio.sleep(INTERVAL_MINUTES * 60)
                
            except Exception as e:
                print(f"Mesaj aktarılırken hata oluştu: {e}")
                await asyncio.sleep(10)

if __name__ == "__main__":
    app.run(main())
