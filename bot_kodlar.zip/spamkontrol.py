import sqlite3
import json
import os
from pyrogram.errors import PeerFlood, UserBannedInChannel, ChatWriteForbidden

async def handle_spam_emergency(e, chat_id, session_name, acc, bot):
    """
    Hesap geçici kısıtlama / spam aldığında devreye giren acil fren mekanizması.
    Hesabın kalıcı ban yemesini önlemek için döngüyü anında durdurur ve paneli bilgilendirir.
    """
    print(f"🚨 [SPAM KORUMA] `{session_name}` hesabı kısıtlama/spam hatası aldı! Hata: {e}")
    
    # 1. Arka plan döngüsünü durdur
    acc["is_running"] = False

    # 2. Kullanıcının paneline bilgi ve uyarı mesajı gönder
    try:
        user_warning = (
            f"🚨 **[ACİL KORUMA DEVREYE GİRDİ]**\n\n"
            f"👤 **Hesap:** `{session_name}`\n"
            f"⚠️ **Sebep:** Telegram hesabınıza geçici kısıtlama/spam kuralı uyguladı (`{type(e).__name__}`).\n\n"
            f"🛡️ **Hesabınız kalıcı spama düşmesin diye otomasyon ve mesaj gönderimi ANINDA DURDURULDU.**\n"
            f"💡 *Kısıtlama kalktığında (genelde 24-48 saat) paneli tekrar başlatabilirsiniz.*"
        )
        await bot.send_message(chat_id, user_warning)
    except Exception as notify_err:
        print(f"⚠️ Kullanıcıya bildirim gönderilemedi: {notify_err}")

    # 3. Log dosyasına kaydet
    try:
        with open("spam_log.txt", "a", encoding="utf-8") as f:
            f.write(f"[{session_name}] - Chat ID: {chat_id} - Hata: {type(e).__name__} ({e})\n")
    except Exception:
        pass
