import asyncio
import os
import random
import datetime
import json
import glob
import sqlite3
from telebot.async_telebot import AsyncTeleBot
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from pyrogram import Client
from pyrogram.enums import ChatType, ChatAction
from pyrogram.errors import FloodWait, ChatWriteForbidden, SessionPasswordNeeded
from pyrogram.raw.functions.account import UpdateStatus

from pyrogram.errors import PeerFlood, UserBannedInChannel, ChatWriteForbidden, UserDeactivated, UserDeactivatedBan
from spamkontrol import handle_spam_emergency

# --- SESSION KİLİTLENME ENGELLEYİCİ (WAL MODU) ---
for session_file in glob.glob("*.session"):
    try:
        conn = sqlite3.connect(session_file)
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.close()
    except Exception:
        pass

# --- KONFİGÜRASYON ---
API_ID = 26963668
API_HASH = "89c3b1b5c65ba624f175f5385b3c14b7"
BOT_TOKEN = "8936913652:AAG98ak1E8laDgJEAnD9qgvAsEaBCihID0E"
ADMIN_USERNAME = "EliteAdminTr" 

# --- DOSYA VE AYAR SİSTEMİ ---
SUB_FILE = "subscribers.txt"
USERS_FILE = "users_map.txt"
SETTINGS_FILE = "msg_settings.json"

def load_settings():
    if os.path.exists(SETTINGS_FILE):
        try:
            with open(SETTINGS_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}
    return {}

def save_settings(data):
    with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

def load_subs():
    subs = {}
    if os.path.exists(SUB_FILE):
        with open(SUB_FILE, "r") as f:
            for line in f:
                if ":" in line:
                    user, expiry = line.strip().split(":")
                    subs[user.lower()] = float(expiry)
    return subs

def save_subs(subs):
    with open(SUB_FILE, "w") as f:
        for user, expiry in subs.items():
            f.write(f"{user}:{expiry}\n")

def save_user_id(username, chat_id):
    if not username: return
    users = load_users_map()
    users[username.lower()] = chat_id
    with open(USERS_FILE, "w") as f:
        for u, cid in users.items():
            f.write(f"{u}:{cid}\n")

def load_users_map():
    users = {}
    if os.path.exists(USERS_FILE):
        with open(USERS_FILE, "r") as f:
            for line in f:
                if ":" in line:
                    u, cid = line.strip().split(":")
                    users[u.lower()] = int(cid)
    return users

def is_authorized(username):
    if not username: return False
    if username.lower() == ADMIN_USERNAME.lower(): return True
    subs = load_subs()
    if username.lower() in subs:
        if subs[username.lower()] > datetime.datetime.now().timestamp():
            return True
    return False

def get_remaining_time_text(username):
    if username.lower() == ADMIN_USERNAME.lower():
        return "Sınırsız (Admin)"
    subs = load_subs()
    if username.lower() in subs:
        expiry = subs[username.lower()]
        now = datetime.datetime.now().timestamp()
        diff = expiry - now
        if diff > 0:
            days = int(diff // 86400)
            hours = int((diff % 86400) // 3600)
            return f"{days} Gün {hours} Saat"
    return "Süresi Doldu / Yok"

user_data = {}
active_tasks = {}

def get_user_state(chat_id):
    if chat_id not in user_data:
        user_data[chat_id] = {
            "active_session": None,
            "accounts": {}, 
            "state": "IDLE",
            "auth_data": {}
        }
    return user_data[chat_id]

def get_account_data(chat_id, session_name):
    u = get_user_state(chat_id)
    if session_name not in u["accounts"]:
        u["accounts"][session_name] = {
            "mode": "slow",
            "is_running": False
        }
    return u["accounts"][session_name]

bot = AsyncTeleBot(BOT_TOKEN, parse_mode="Markdown")

def get_sessions_file(chat_id):
    return f"sessions_{chat_id}.txt"

def get_registered_sessions(chat_id):
    file_path = get_sessions_file(chat_id)
    if not os.path.exists(file_path):
        return []
    with open(file_path, "r", encoding="utf-8") as f:
        return [line.strip() for line in f if line.strip()]

def add_registered_session(chat_id, session_name):
    sessions = get_registered_sessions(chat_id)
    if session_name not in sessions:
        with open(get_sessions_file(chat_id), "a", encoding="utf-8") as f:
            f.write(f"{session_name}\n")

def remove_registered_session(chat_id, session_name):
    file_path = get_sessions_file(chat_id)
    if not os.path.exists(file_path):
        return
    
    clean_target = session_name.split("|")[0].strip().lower()
    
    with open(file_path, "r", encoding="utf-8") as f:
        lines = f.readlines()
        
    with open(file_path, "w", encoding="utf-8") as f:
        for line in lines:
            line_clean = line.strip().split("|")[0].strip().lower()
            if line_clean != clean_target and clean_target not in line_clean:
                f.write(line)


def main_keyboard():
    markup = InlineKeyboardMarkup()
    markup.row(
        InlineKeyboardButton("▶️ Başlat", callback_data="start_bot"),
        InlineKeyboardButton("⏹️ Durdur", callback_data="stop_bot")
    )
    markup.row(
        InlineKeyboardButton("➕ Yeni Hesap Ekle", callback_data="add_account"),
        InlineKeyboardButton("📋 Hesap Liste/Değiştir", callback_data="list_accounts")
    )
    markup.row(
        InlineKeyboardButton("✏️ Mesaj Bilgisi", callback_data="change_msg"),
        InlineKeyboardButton("⏱️ Süre Ayarla", callback_data="change_wait")
    )
    markup.row(
        InlineKeyboardButton("🚫 İstisna Gruplar", callback_data="manage_blacklists")
    )
    markup.row(
        InlineKeyboardButton("❌ Hesap Sil", callback_data="delete_account")
    )
    return markup

# --- KULLANICIYA BİLDİRİM GÖNDEREN EKLE KOMUTU ---
@bot.message_handler(commands=['ekle'])
async def add_sub_cmd(message):
    if not message.from_user.username or message.from_user.username.lower() != ADMIN_USERNAME.lower():
        return
    parts = message.text.split()
    if len(parts) < 3:
        await bot.send_message(message.chat.id, "⚠️ Kullanım: `/ekle kullanıcı_adı gün_sayısı`\nÖrnek: `/ekle ahmet 30`")
        return
    target_user = parts[1].replace("@", "").lower()
    try:
        days = float(parts[2])
    except ValueError:
        await bot.send_message(message.chat.id, "❌ Gün sayısı sayı olmalıdır!")
        return
    subs = load_subs()
    now = datetime.datetime.now().timestamp()
    current_expiry = subs.get(target_user, now)
    if current_expiry < now:
        current_expiry = now
    new_expiry = current_expiry + (days * 86400)
    subs[target_user] = new_expiry
    save_subs(subs)
    
    await bot.send_message(message.chat.id, f"✅ @{target_user} kullanıcısına **{days} gün** abonelik eklendi!")

    # --- KULLANICIYA DÜŞEN BİLDİRİM BÖLÜMÜ ---
    users = load_users_map()
    target_chat_id = users.get(target_user)
    if target_chat_id:
        try:
            rem_text = get_remaining_time_text(target_user)
            user_notify = (
                f"🎉 **Aboneliğiniz Aktif Edildi / Uzatıldı!**\n\n"
                f"👤 **Kullanıcı Adı:** @{target_user}\n"
                f"➕ **Eklene Süre:** {days} Gün\n"
                f"⏳ **Toplam Kalan Süreniz:** `{rem_text}`\n\n"
                f"Komutları ve paneli kullanmak için `/start` yazabilirsiniz."
            )
            await bot.send_message(target_chat_id, user_notify)
        except Exception as e:
            print(f"Kullanıcıya bildirim gönderilemedi: {e}")

@bot.message_handler(commands=['cikar'])
async def remove_sub_cmd(message):
    if not message.from_user.username or message.from_user.username.lower() != ADMIN_USERNAME.lower():
        return
    parts = message.text.split()
    if len(parts) < 2:
        await bot.send_message(message.chat.id, "⚠️ Kullanım: `/cikar kullanıcı_adı`\nÖrnek: `/cikar ahmet`")
        return
    target_user = parts[1].replace("@", "").lower()
    subs = load_subs()
    if target_user in subs:
        del subs[target_user]
        save_subs(subs)
        await bot.send_message(message.chat.id, f"❌ @{target_user} kullanıcısının aboneliği silindi!")
    else:
        await bot.send_message(message.chat.id, "⚠️ Kullanıcı abonelik listesinde bulunamadı.")

@bot.message_handler(commands=['liste'])
async def list_subs_cmd(message):
    if not message.from_user.username or message.from_user.username.lower() != ADMIN_USERNAME.lower():
        return
    subs = load_subs()
    if not subs:
        await bot.send_message(message.chat.id, "📋 Aktif abone bulunmuyor.")
        return
    text = "📋 **Aktif Aboneler:**\n\n"
    now = datetime.datetime.now().timestamp()
    for user, expiry in subs.items():
        diff = expiry - now
        if diff > 0:
            days = int(diff // 86400)
            hours = int((diff % 86400) // 3600)
            status = f"{days} Gün {hours} Saat kaldı"
        else:
            status = "Süresi doldu"
        text += f"👤 @{user} -> `{status}`\n"
    await bot.send_message(message.chat.id, text)

@bot.message_handler(commands=['start'])
async def send_welcome(message):
    if message.from_user.username:
        save_user_id(message.from_user.username, message.chat.id)
    try:
        users = load_users_map()
        admin_chat_id = users.get(ADMIN_USERNAME.lower())
        if admin_chat_id:
            user_fullname = f"{message.from_user.first_name or ''} {message.from_user.last_name or ''}".strip()
            username_text = f"(@{message.from_user.username})" if message.from_user.username else "(Kullanıcı adı yok)"
            admin_msg = f"🔔 **Yeni Kullanıcı Botu Çalıştırdı!**\n\n👤 **İsim:** {user_fullname}\n🏷️ **Kullanıcı Adı:** {username_text}"
            await bot.send_message(admin_chat_id, admin_msg)
    except Exception:
        pass

    u = get_user_state(message.chat.id)
    session = u["active_session"]
    if session:
        acc = get_account_data(message.chat.id, session)
        status = "🟢 Çalışıyor" if acc["is_running"] else "🔴 Durduruldu"
        if acc["mode"] == "slow":
            mode_text = "🐢 Yavaş Mod "
        elif acc["mode"] == "medium":
            mode_text = "⚡ Orta Mod"
        elif acc["mode"] == "fast":
            mode_text = "🚀 Hızlı Mod (Eski Hesaplar İçin)"
        else:
            mode_text = "Seçilmedi"
        active_acc = session
    else:
        status = "🔴 Durduruldu"
        mode_text = "Seçilmedi"
        active_acc = "Seçilmedi"

    remaining_time = get_remaining_time_text(message.from_user.username or "")

    await bot.send_message(
        message.chat.id, 
        f"🛠️ **Userbot Kontrol Paneli**\n\n"
        f"Mevcut Durum: {status}\n"
        f"Aktif Hesap: `{active_acc}`\n"
        f"Mevcut Mod: **{mode_text}**\n"
        f"⏳ **Kalan Süre:** `{remaining_time}`", 
        reply_markup=main_keyboard()
    )

@bot.callback_query_handler(func=lambda call: True)
async def callback_listener(call):
    if call.from_user.username:
        save_user_id(call.from_user.username, call.message.chat.id)

    if not is_authorized(call.from_user.username):
        await bot.answer_callback_query(call.id, "❌ Kullanma hakkınız bulunmamaktadır.", show_alert=True)
        return

    chat_id = call.message.chat.id
    u = get_user_state(chat_id)
    session = u["active_session"]
    
    if call.data == "start_bot":
        if not session:
            await bot.answer_callback_query(call.id, "⚠️ Önce bir hesap seçmelisiniz!")
            return
        acc = get_account_data(chat_id, session)
        if acc["is_running"]:
            await bot.answer_callback_query(call.id, f"⚠️ `{session}` hesabı zaten çalışıyor!")
            return
        acc["is_running"] = True
        task_key = (chat_id, session)
        task = asyncio.create_task(single_account_worker(chat_id, session))
        active_tasks[task_key] = task
        await bot.answer_callback_query(call.id, f"🚀 {session} için işlem başlatıldı!")
        await bot.send_message(chat_id, f"🚀 **`{session}` hesabı için gönderim başladı.**")
        
    elif call.data == "stop_bot":
        if not session:
            await bot.answer_callback_query(call.id, "⚠️ Seçili hesap yok!")
            return
        acc = get_account_data(chat_id, session)
        if not acc["is_running"]:
            await bot.answer_callback_query(call.id, f"⚠️ `{session}` zaten çalışmıyor!")
            return
        acc["is_running"] = False
        task_key = (chat_id, session)
        if task_key in active_tasks:
            active_tasks[task_key].cancel()
            del active_tasks[task_key]
        await bot.answer_callback_query(call.id, f"🛑 {session} durduruldu!")
        await bot.send_message(chat_id, f"🛑 **`{session}` hesabı durduruldu.**")
        
    elif call.data == "change_msg":
        if not session:
            await bot.answer_callback_query(call.id, "⚠️ Önce bir hesap seçmelisiniz!")
            return
        markup = InlineKeyboardMarkup()
        markup.row(InlineKeyboardButton("📝 Normal Mesaj (Standart)", callback_data="msg_mode_normal"))
        markup.row(InlineKeyboardButton("💎 Premium Emojili Mesaj (Grup/Kanal)", callback_data="msg_mode_premium"))
        await bot.send_message(chat_id, f"✏️ **`{session}` Hesabı İçin Mesaj Gönderim Türünü Seçin:**", reply_markup=markup)
        await bot.answer_callback_query(call.id)

    elif call.data == "msg_mode_normal":
        u["state"] = "WAITING_NORMAL_TEXT"
        await bot.send_message(chat_id, "📝 **Gönderilmesini istediğiniz reklam mesajınızı buraya yazıp atın:**")
        await bot.answer_callback_query(call.id)

    elif call.data == "msg_mode_premium":
        u["state"] = "WAITING_PREMIUM_SOURCE"
        await bot.send_message(chat_id, "💎 **Premium Emojili Mesaj Modu:**\n\nLütfen reklam mesajını attığınız **grubun veya kanalın kullanıcı adını** iletin:\n*(Örnek: @reklam_grubum veya reklam_grubum)*")
        await bot.answer_callback_query(call.id)

    elif call.data == "manage_blacklists":
        if not session:
            await bot.answer_callback_query(call.id, "⚠️ Önce bir hesap seçmelisiniz!")
            return
        
        settings = load_settings()
        user_settings = settings.get(str(chat_id), {}).get(session, {})
        blacklist = user_settings.get("blacklist", [])
        
        bl_text = "\n".join([f"• @{b}" for b in blacklist]) if blacklist else "*(Henüz eklenmemiş)*"
        
        markup = InlineKeyboardMarkup()
        markup.row(
            InlineKeyboardButton("➕ Grup Ekle", callback_data="add_blacklist_group"),
            InlineKeyboardButton("🧹 Listeyi Temizle", callback_data="clear_blacklist")
        )
        
        await bot.send_message(
            chat_id,
            f"🚫 **`{session}` İçin İstisna (Engellenen) Gruplar:**\n\n{bl_text}\n\n"
            f"Hangi gruba mesaj gönderilmesini istemiyorsanız @kullaniciadi şeklinde yazıp ekleyebilirsiniz.",
            reply_markup=markup
        )
        await bot.answer_callback_query(call.id)

    elif call.data == "add_blacklist_group":
        u["state"] = "WAITING_BLACKLIST_INPUT"
        await bot.send_message(chat_id, "🚫 **Mesaj gönderilmeyecek istisna grubun kullanıcı adını yazın:**\n*(Örnek: @pasif_grup veya pasif_grup)*")
        await bot.answer_callback_query(call.id)

    elif call.data == "clear_blacklist":
        if session:
            settings = load_settings()
            if str(chat_id) in settings and session in settings[str(chat_id)]:
                settings[str(chat_id)][session]["blacklist"] = []
                save_settings(settings)
            await bot.send_message(chat_id, f"🧹 `{session}` hesabı için istisna grup listesi temizlendi!", reply_markup=main_keyboard())
        await bot.answer_callback_query(call.id)

    elif call.data == "change_wait":
        if not session:
            await bot.answer_callback_query(call.id, "⚠️ Önce bir hesap seçmelisiniz!")
            return
        markup = InlineKeyboardMarkup()
        markup.row(
            InlineKeyboardButton("🐢 Yavaş Mod (15-80s)", callback_data="set_mode_slow"),
            InlineKeyboardButton("⚡ Orta Mod (7.5-40s)", callback_data="set_mode_medium")
        )
        markup.row(
            InlineKeyboardButton("🚀 Hızlı Mod (3-10s)", callback_data="set_mode_fast")
        )
        await bot.send_message(chat_id, f"⏱️ **`{session}` Hesabı İçin Hız Modunu Seçin:**", reply_markup=markup)
        await bot.answer_callback_query(call.id)

    elif call.data == "set_mode_slow":
        if session:
            acc = get_account_data(chat_id, session)
            acc["mode"] = "slow"
            await bot.send_message(chat_id, f"✅ `{session}` hesabı **🐢 Yavaş Mod** olarak ayarlandı.", reply_markup=main_keyboard())
        await bot.answer_callback_query(call.id)

    elif call.data == "set_mode_medium":
        if session:
            acc = get_account_data(chat_id, session)
            acc["mode"] = "medium"
            await bot.send_message(chat_id, f"✅ `{session}` hesabı **⚡ Orta Mod** olarak ayarlandı.", reply_markup=main_keyboard())
        await bot.answer_callback_query(call.id)

    elif call.data == "set_mode_fast":
        if session:
            acc = get_account_data(chat_id, session)
            acc["mode"] = "fast"
            await bot.send_message(chat_id, f"✅ `{session}` hesabı **🚀 Hızlı Mod** olarak ayarlandı.", reply_markup=main_keyboard())
        await bot.answer_callback_query(call.id)

    elif call.data == "list_accounts":
        sessions = get_registered_sessions(chat_id)
        if not sessions:
            await bot.send_message(chat_id, "❌ Kayıtlı hesap bulunamadı.")
            return

        markup = InlineKeyboardMarkup()
        for s in sessions:
            parts = s.split("|")
            file_key = parts[0]
            display_title = parts[1] if len(parts) > 1 else parts[0]

            acc = get_account_data(chat_id, file_key)
            run_status = "🟢 " if acc.get("is_running") else ""
            prefix = "✅ " if file_key == u.get("active_session") else ""
            markup.add(InlineKeyboardButton(f"{run_status}{prefix}{display_title}", callback_data=f"select_session:{file_key}"))

        # Işık hızında açılan menünün altına canlı güncelleme butonu koyuyoruz
        markup.add(InlineKeyboardButton("🔄 İsimleri Güncelle", callback_data="update_account_names"))

        await bot.send_message(chat_id, "📂 **Hesaplarınız:**", reply_markup=markup)

    elif call.data == "update_account_names":
        sessions = get_registered_sessions(chat_id)
        if not sessions:
            await bot.answer_callback_query(call.id, "❌ Güncellenecek kayıtlı hesap bulunamadı.", show_alert=True)
            return

        await bot.answer_callback_query(call.id, "✅ Hesap listesi güncellendi!...")

        file_path = get_sessions_file(chat_id)
        semaphore = asyncio.Semaphore(20)

        async def check_session_fast(s):
            async with semaphore:
                file_key = s.split("|")[0].strip()
                session_file_name = file_key.replace(' ', '_')

                if not os.path.exists(f"{session_file_name}.session"):
                    return s

                temp_app = Client(
                    session_file_name,
                    api_id=API_ID,
                    api_hash=API_HASH,
                    no_updates=True,
                    in_memory=False
                )
                try:
                    await asyncio.wait_for(temp_app.connect(), timeout=2.5)

                    from pyrogram.raw import functions
                    full_user = await temp_app.invoke(functions.users.GetFullUser(id=await temp_app.resolve_peer("me")))
                    me = full_user.users[0]

                    await temp_app.disconnect()

                    name_parts = [me.first_name, me.last_name]
                    full_name = " ".join([p for p in name_parts if p])
                    username = f"(@{me.username})" if me.username else ""
                    display_name = f"{full_name} {username}".strip()

                    acc = get_account_data(chat_id, file_key)
                    acc["display_name"] = display_name

                    return f"{file_key}|{display_name}"
                except Exception:
                    try:
                        await temp_app.disconnect()
                    except Exception:
                        pass
                    return s

        updated_sessions = await asyncio.gather(*[check_session_fast(s) for s in sessions])

        with open(file_path, "w", encoding="utf-8") as f:
            for us in updated_sessions:
                f.write(f"{us}\n")

        await bot.answer_callback_query(call.id, "✅ Hesap listesi güncellendi!", show_alert=False)




    elif call.data.startswith("select_session:"):
        selected = call.data.split("select_session:")[1]
        u["active_session"] = selected
        get_account_data(chat_id, selected)
        await bot.send_message(chat_id, f"✅ Aktif kontrol hesabı `{selected}` olarak seçildi.", reply_markup=main_keyboard())

    elif call.data == "add_account":
        u["state"] = "WAITING_PHONE"
        u["auth_data"] = {}
        await bot.send_message(chat_id, "📱 **Lütfen eklemek istediğiniz telefon numarasını girin:**\n*(Örnek: +905xxxxxxxxx)*")

    elif call.data == "delete_account":
        sessions = get_registered_sessions(chat_id)
        if not sessions:
            await bot.send_message(chat_id, "❌ Silinecek kayıtlı hesap bulunamadı.")
            return
        markup = InlineKeyboardMarkup()
        for s in sessions:
            parts = s.split("|")
            file_key = parts[0].strip()
            display_title = parts[1].strip() if len(parts) > 1 else parts[0]
            markup.add(InlineKeyboardButton(f"🗑️ {display_title}", callback_data=f"c_del:{file_key}"))
        await bot.send_message(chat_id, "❌ **Silmek istediğiniz hesabı seçin:**", reply_markup=markup)

    elif call.data.startswith("c_del:"):
        target_session = call.data.split("c_del:")[1]
        try:
            await bot.answer_callback_query(call.id)
        except Exception:
            pass

        markup = InlineKeyboardMarkup()
        markup.row(
            InlineKeyboardButton("✅ Evet, Sil", callback_data=f"d_del:{target_session}"),
            InlineKeyboardButton("❌ İptal", callback_data="cancel_delete")
        )
        await bot.send_message(chat_id, f"⚠️ `{target_session}` **hesabını silmek istediğinize emin misiniz?**", reply_markup=markup)

    elif call.data == "cancel_delete":
        try:
            await bot.answer_callback_query(call.id, "İşlem iptal edildi.")
        except Exception:
            pass
        await bot.send_message(chat_id, "⚠️ **İptal edildi.**", reply_markup=main_keyboard())

    elif call.data.startswith("d_del:"):
        target_session = call.data.split("d_del:")[1]

        try:
            await bot.answer_callback_query(call.id, "✅ Hesap siliniyor...")
        except Exception:
            pass

        task_key = (chat_id, target_session)
        if task_key in active_tasks:
            try:
                active_tasks[task_key].cancel()
                del active_tasks[task_key]
            except Exception:
                pass

        # 1. Metin dosyasından temizler
        remove_registered_session(chat_id, target_session)

        # 2. Bellekten temizler
        if target_session in u.get("accounts", {}):
            del u["accounts"][target_session]
        if u.get("active_session") == target_session:
            u["active_session"] = None

        # 3. Klasördeki fiziki .session dosyasını siler
        clean_key = target_session.split("(")[0].replace(' ', '_').strip('_').lower()
        for f in os.listdir("."):
            if ".session" in f:
                f_clean = f.lower().replace('.session', '')
                if clean_key in f_clean or f_clean in clean_key:
                    try:
                        os.remove(f)
                    except Exception:
                        pass

        # 4. USERS_FILE haritasından temizler
        if os.path.exists(USERS_FILE):
            try:
                with open(USERS_FILE, "r", encoding="utf-8") as f:
                    lines = f.readlines()
                with open(USERS_FILE, "w", encoding="utf-8") as f:
                    for line in lines:
                        if not line.startswith(f"{target_session}|") and not line.startswith(f"{target_session}:"):
                            f.write(line)
            except Exception:
                pass

        await bot.send_message(chat_id, f"✅ `{target_session}` **silindi!**", reply_markup=main_keyboard())



async def finalize_login(chat_id, client):
    me = await client.get_me()
    name_parts = [me.first_name, me.last_name]
    full_name = " ".join([p for p in name_parts if p])
    username = f"(@{me.username})" if me.username else ""
    session_title = f"{full_name} {username}".strip()
    old_session = f"{client.name}.session"
    new_session_filename = f"{session_title.replace(' ', '_')}"
    new_session_file = f"{new_session_filename}.session"
    await client.disconnect()
    if os.path.exists(old_session):
        if os.path.exists(new_session_file): os.remove(new_session_file)
        os.rename(old_session, new_session_file)
    add_registered_session(chat_id, session_title)
    u = get_user_state(chat_id)
    u["active_session"] = session_title
    get_account_data(chat_id, session_title)
    u["state"] = "IDLE"
    await bot.send_message(chat_id, f"🎉 Hesabınız eklendi:\n👤 **{session_title}**", reply_markup=main_keyboard())

@bot.message_handler(chat_types=['private'], func=lambda m: True)
async def text_listener(message):
    if message.from_user.username:
        save_user_id(message.from_user.username, message.chat.id)

    if not is_authorized(message.from_user.username):
        await bot.send_message(message.chat.id, "❌ **Kullanma hakkınız bulunmamaktadır.** Abonelik için @EliteAdminTr ile görüşün.")
        return

    chat_id = message.chat.id
    u = get_user_state(chat_id)
    state = u["state"]
    session = u["active_session"]

    if state == "WAITING_NORMAL_TEXT":
        if not session:
            await bot.send_message(chat_id, "⚠️ Aktif hesap seçili değil!")
            u["state"] = "IDLE"
            return
        settings = load_settings()
        if str(chat_id) not in settings: settings[str(chat_id)] = {}
        if session not in settings[str(chat_id)]: settings[str(chat_id)][session] = {}
        
        settings[str(chat_id)][session]["mode"] = "NORMAL"
        settings[str(chat_id)][session]["content"] = message.text
        save_settings(settings)
        u["state"] = "IDLE"
        await bot.send_message(chat_id, f"✅ `{session}` hesabı için **Standart Normal Mesaj** kaydedildi!", reply_markup=main_keyboard())

    elif state == "WAITING_PREMIUM_SOURCE":
        if not session:
            await bot.send_message(chat_id, "⚠️ Aktif hesap seçili değil!")
            u["state"] = "IDLE"
            return
        target_chat = message.text.strip().replace("https://t.me/", "").replace("@", "")
        settings = load_settings()
        if str(chat_id) not in settings: settings[str(chat_id)] = {}
        if session not in settings[str(chat_id)]: settings[str(chat_id)][session] = {}

        settings[str(chat_id)][session]["mode"] = "PREMIUM"
        settings[str(chat_id)][session]["content"] = target_chat
        save_settings(settings)
        u["state"] = "IDLE"
        await bot.send_message(chat_id, f"✅ `{session}` hesabı için Premium mod aktif!\n\n📌 Mesajlar artık **@{target_chat}** grubundan/kanalından çekilecek.", reply_markup=main_keyboard())

    elif state == "WAITING_BLACKLIST_INPUT":
        if not session:
            await bot.send_message(chat_id, "⚠️ Aktif hesap seçili değil!")
            u["state"] = "IDLE"
            return
        target_bl = message.text.strip().replace("https://t.me/", "").replace("@", "").lower()
        settings = load_settings()
        if str(chat_id) not in settings: settings[str(chat_id)] = {}
        if session not in settings[str(chat_id)]: settings[str(chat_id)][session] = {}
        
        current_bl = settings[str(chat_id)][session].get("blacklist", [])
        if target_bl not in current_bl:
            current_bl.append(target_bl)
            settings[str(chat_id)][session]["blacklist"] = current_bl
            save_settings(settings)
            await bot.send_message(chat_id, f"✅ **@{target_bl}** grubu istisna listesine eklendi! Bu gruba mesaj atılmayacak.", reply_markup=main_keyboard())
        else:
            await bot.send_message(chat_id, f"⚠️ **@{target_bl}** zaten istisna listesinde var.", reply_markup=main_keyboard())
        u["state"] = "IDLE"

    elif state == "WAITING_PHONE":
        phone_clean = message.text.strip().replace(" ", "").replace("-", "")
        u["auth_data"]["phone"] = phone_clean
        temp_session = f"temp_{chat_id}_{random.randint(1000, 9999)}"
        u["auth_data"]["temp_session"] = temp_session
        
        await bot.send_message(chat_id, "⏳ **Doğrulama kodu talep ediliyor, lütfen bekleyin...**")
        await asyncio.sleep(2)
        
        try:
            client = Client(
                temp_session, 
                api_id=API_ID, 
                api_hash=API_HASH,
                device_model="Xiaomi 2201116PG",
                system_version="Android 13",
                app_version="10.2.1",
                lang_code="tr",
                no_updates=True
            )
            await client.connect()
            code_info = await client.send_code(phone_clean)
            u["auth_data"]["client"] = client
            u["auth_data"]["phone_code_hash"] = code_info.phone_code_hash
            u["state"] = "WAITING_CODE"
            await bot.send_message(chat_id, "📩 **Giriş kodu gönderildi!**\n\n⚠️ **ÖNEMLİ:** Kodu **aralarında boşluk bırakarak** yazın.\n*Örnek: 1 2 3 4 5*")
        except Exception as e:
            u["state"] = "IDLE"
            await bot.send_message(chat_id, f"❌ Hata: `{e}`", reply_markup=main_keyboard())

    elif state == "WAITING_CODE":
        code = message.text.strip().replace(" ", "").replace("-", "")
        client = u["auth_data"]["client"]
        try:
            await client.sign_in(u["auth_data"]["phone"], u["auth_data"]["phone_code_hash"], code)
            await finalize_login(chat_id, client)
        except SessionPasswordNeeded:
            u["state"] = "WAITING_PASSWORD"
            await bot.send_message(chat_id, "🔑 **Hesabınızda 2FA (İki Adımlı Doğrulama) var.** Lütfen şifrenizi girin:")
        except Exception as e:
            await bot.send_message(chat_id, f"❌ Kod Hatası: `{e}`")

    elif state == "WAITING_PASSWORD":
        client = u["auth_data"]["client"]
        try:
            await client.check_password(message.text.strip())
            await finalize_login(chat_id, client)
        except Exception as e:
            await bot.send_message(chat_id, f"❌ Şifre Hatası: `{e}`")

# --- MESAJ GÖNDERME MOTORU ---
async def single_account_worker(chat_id, session_name):
    acc = get_account_data(chat_id, session_name)
    session_file_name = session_name.replace(' ', '_')
    
    if not os.path.exists(f"{session_file_name}.session"):
        print(f"❌ Oturum dosyası bulunamadı: {session_file_name}.session")
        await bot.send_message(chat_id, f"❌ `{session_name}` **oturumu bulunamadı.**")
        acc["is_running"] = False
        return

    try:
        async with Client(session_file_name, api_id=API_ID, api_hash=API_HASH, no_updates=True) as app:
            me = await app.get_me()
            print(f"Hesabınızla giriş yapıldı: {me.first_name}")

            async def keep_online(app):
                while True:
                    try:
                        await app.invoke(UpdateStatus(offline=False))
                    except Exception:
                        pass
                    await asyncio.sleep(200)

            asyncio.create_task(keep_online(app))
            print("**ÇEVRİMİÇİ KALMA BAŞLATILDI!**")
            
            while acc["is_running"]:
                settings = load_settings()
                # Önce tam session_name ile, bulamazsa '|' öncesindeki file_key ile arıyoruz
                clean_key = session_name.split("|")[0].strip()
                user_settings = settings.get(str(chat_id), {}).get(session_name) or settings.get(str(chat_id), {}).get(clean_key)


                if not user_settings:
                    print("❌ Mesaj ayarı bulunamadı!")
                    await bot.send_message(chat_id, f"⚠️ `{session_name}` hesabı için henüz bir reklam mesajı/grubu ayarlanmamış! Panelden '✏️ Mesaj Bilgisi' kısmına gidin.")
                    await asyncio.sleep(30)
                    continue

                mode = user_settings.get("mode", "NORMAL")
                content = user_settings.get("content", "")
                blacklist = user_settings.get("blacklist", [])
                blacklist_lower = [b.lower() for b in blacklist]

                target_msg = None
                is_premium_copy = False
                source_chat_id = None

                if mode == "PREMIUM":
                    try:
                        async for m in app.get_chat_history(content, limit=1):
                            target_msg = m
                            is_premium_copy = True
                            source_chat_id = m.chat.id
                            break
                    except Exception as e:
                        print(f"❌ Kaynak gruptan mesaj çekilemedi: {e}")
                        await bot.send_message(chat_id, f"⚠️ `{session_name}` hesabı **@{content}** grubundaki mesajı okuyamadı! Hesabın o gruba üye olduğundan emin olun.")
                        await asyncio.sleep(30)
                        continue
                else:
                    target_msg = content
                    is_premium_copy = False

                if not target_msg:
                    await asyncio.sleep(30)
                    continue

                current_mode = acc.get("mode", "slow")
                if current_mode == "fast":
                    msg_wait_min, msg_wait_max = 3, 7
                    loop_wait_min, loop_wait_max = 5, 20
                elif current_mode == "medium":
                    msg_wait_min, msg_wait_max = 7.5, 40
                    loop_wait_min, loop_wait_max = 40, 60
                else:
                    msg_wait_min, msg_wait_max = 50, 200
                    loop_wait_min, loop_wait_max = 100, 200

                print("-" * 30)
                print(f"Yeni mesaj gönderme döngüsü başlıyor... (Mod: {current_mode})")

                dialogs_to_message = []
                async for dialog in app.get_dialogs():
                    chat = dialog.chat
                    if chat.type in [ChatType.GROUP, ChatType.SUPERGROUP]:
                        # 1. KURAL: Mesajın çekildiği kaynak gruba mesaj atma
                        if is_premium_copy and source_chat_id and chat.id == source_chat_id:
                            print(f"🛑 {chat.title} kaynak grup olduğu için atlandı.")
                            continue
                        
                        # 2. KURAL: İstisna / Kara listedeki gruplara mesaj atma
                        chat_username = (chat.username or "").lower()
                        if chat_username and chat_username in blacklist_lower:
                            print(f"🛑 @{chat_username} istisna listesinde olduğu için atlandı.")
                            continue

                        try:
                            await app.get_chat_members_count(chat.id)
                        except:
                            pass
                        dialogs_to_message.append(dialog)

                if not dialogs_to_message:
                    print("!! Hiç uygun grup bulunamadı.")
                    await asyncio.sleep(60)
                    continue

                num_to_select = min(len(dialogs_to_message), 5)
                selected_dialogs = random.sample(dialogs_to_message, num_to_select)

                for dialog in selected_dialogs:
                    if not acc["is_running"]: break
                    chat = dialog.chat

                    try:
                        print(f"-> {chat.title} grubuna mesaj gönderiliyor...")

                        try:
                            await app.send_chat_action(chat.id, ChatAction.TYPING)
                            await asyncio.sleep(3)
                        except Exception as e:
                            print(f"⚠️ Yazıyor simülasyonu hatası: {e}")

                        if is_premium_copy:
                            await target_msg.copy(chat.id)
                        else:
                            await app.send_message(chat.id, target_msg)

                        print(f"--> Mesaj başarıyla gönderildi.")
                        wait_time = random.uniform(msg_wait_min, msg_wait_max)
                        print(f"--> Bir sonraki mesaj için {wait_time:.2f} saniye bekleniyor.")
                        await asyncio.sleep(wait_time)

                    except FloodWait as e:
                        print(f"--> FloodWait hatası! {e.value} saniye bekleniyor.")
                        await asyncio.sleep(e.value)

                    # 1. TEK BİR GRUPTAKİ YETKİSİZLİK (Hesap sağlam, sadece o grupta yazamaz):
                    except ChatWriteForbidden:
                        print(f"--> {chat.title} grubunda yazma yetkiniz yok, grup atlanıyor.")
                        continue

                    # 2. HESABIN GENEL SPAM / KISITLAMA ALMASI (Hesabı korumak için durdur):
                    except (PeerFlood, UserBannedInChannel, UserDeactivated, UserDeactivatedBan) as e:
                        await handle_spam_emergency(e, chat_id, session_name, acc, bot)
                        break

                    except Exception as e:
                        print(f"--> Beklenmedik hata: {e}")


                print("-" * 30)
                long_wait_time = random.uniform(loop_wait_min, loop_wait_max)
                print(f"Döngü tamamlandı. {long_wait_time:.2f} saniye sonra tekrar başlayacak.")
                await asyncio.sleep(long_wait_time)

    except Exception as e:
        print(f"Worker hatası [{session_name}]: {e}")
        acc["is_running"] = False

if __name__ == "__main__":
    import asyncio
    asyncio.run(bot.infinity_polling())
